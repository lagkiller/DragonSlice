//*********************************
*************DISCLAIMER************
***********************************
*This is not done, I still have to*
**finish character creation, etc.**
*I'll add a map editor so you guys*
****can make maps/towns for me*****
*********************************//

To start the game run DragonSlice.exe

Controls:
W - move up
S - move down
A - move left
D - move right

Arrow Keys - move camera/navigate menu
Enter - ...this should be obvious...

C - move camera back to character (same thing as pressing space in LoL)
F - lock/unlock camera to character (same thing as pressing Y in LoL)